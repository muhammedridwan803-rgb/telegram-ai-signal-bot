import json

# File to store signals
SIGNALS_FILE = 'signals.json'

def save_signal(signal_data):
    """Save signal to file"""
    try:
        # Load existing signals
        try:
            with open(SIGNALS_FILE, 'r') as f:
                signals = json.load(f)
        except FileNotFoundError:
            signals = []
        
        # Add new signal with ID
        signal_id = len(signals) + 1
        signal_data['id'] = signal_id
        signals.append(signal_data)
        
        # Save back
        with open(SIGNALS_FILE, 'w') as f:
            json.dump(signals, f, indent=2)
        
        return signal_id
    except Exception as e:
        print(f"Error saving signal: {e}")
        return None

def format_signal_message(signal_data):
    """Format signal for Telegram message"""
    market_emoji = {
        'forex': '📈',
        'futures': '⚡', 
        'crypto': '🪙'
    }
    
    emoji = market_emoji.get(signal_data.get('market_type', 'forex'), '📊')
    
    message = f"{emoji} **SIGNAL #{signal_data.get('id', 'NEW')}**\n"
    message += "─" * 30 + "\n"
    
    # Basic info
    if 'symbol' in signal_data:
        message += f"**{signal_data['symbol']} {signal_data.get('type', '').upper()}**\n"
    
    if 'entry' in signal_data:
        message += f"📍 Entry: `{signal_data['entry']}`\n"
    
    if 'sl' in signal_data:
        message += f"🛑 Stop Loss: `{signal_data['sl']}`\n"
    
    if 'tp' in signal_data:
        tps = signal_data['tp']
        if isinstance(tps, list):
            for i, tp in enumerate(tps, 1):
                message += f"🎯 TP{i}: `{tp}`\n"
        else:
            message += f"🎯 Take Profit: `{tps}`\n"
    
    if 'timeframe' in signal_data:
        message += f"⏰ Timeframe: {signal_data['timeframe']}\n"
    
    if 'notes' in signal_data:
        message += f"\n📝 Notes: {signal_data['notes']}\n"
    
    # Risk info if available
    if 'rr_ratio' in signal_data:
        rr = signal_data['rr_ratio']
        status = "✅" if rr >= 1.5 else "⚠️" if rr >= 1.0 else "❌"
        message += f"\n⚖️ Risk/Reward: {rr:.2f} {status}\n"
    
    # Tags
    market = signal_data.get('market_type', 'forex')
    message += f"\n#{market.upper()}"
    if 'symbol' in signal_data:
        message += f" #{signal_data['symbol'].replace('/', '')}"
    
    return message

def calculate_rr_ratio(entry, sl, tp):
    """Calculate Risk/Reward ratio"""
    try:
        entry = float(entry)
        sl = float(sl)
        tp = float(tp[0] if isinstance(tp, list) else tp)
        
        risk = abs(entry - sl)
        reward = abs(tp - entry)
        
        if risk > 0:
            return reward / risk
        return 0
    except:
        return 0
