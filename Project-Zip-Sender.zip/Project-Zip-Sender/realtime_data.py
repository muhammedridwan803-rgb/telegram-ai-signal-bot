"""
STEP 1: REAL-TIME MARKET DATA
Simple script to get actual live prices
"""

import yfinance as yf
import pandas as pd
from datetime import datetime

def get_live_price(symbol):
    """Get actual live market price"""
    try:
        print(f"📡 Fetching live price for {symbol}...")
        
        # Get real data from Yahoo Finance
        ticker = yf.Ticker(symbol)
        
        # Get latest data (1 minute interval)
        data = ticker.history(period='1d', interval='1m')
        
        if data.empty:
            print(f"❌ No data for {symbol}")
            return None
        
        # Get latest price
        latest = data.iloc[-1]
        current_price = latest['Close']
        volume = latest['Volume']
        
        # Get some history for context
        if len(data) > 1:
            prev_price = data.iloc[-2]['Close']
            change_pct = ((current_price - prev_price) / prev_price) * 100
        else:
            change_pct = 0
        
        result = {
            'symbol': symbol,
            'price': round(current_price, 4),
            'change': round(change_pct, 2),
            'volume': int(volume),
            'high': round(latest['High'], 4),
            'low': round(latest['Low'], 4),
            'time': datetime.now().strftime('%H:%M:%S'),
            'data_points': len(data)
        }
        
        print(f"✅ {symbol}: ${result['price']} ({result['change']}%)")
        return result
        
    except Exception as e:
        print(f"❌ Error fetching {symbol}: {e}")
        return None

def test_real_data():
    """Test with real market symbols"""
    print("🧪 TESTING REAL-TIME DATA FETCH")
    print("=" * 40)
    
    # Real market symbols
    test_symbols = [
        ('EURUSD=X', 'EUR/USD'),
        ('GC=F', 'GOLD'),
        ('BTC-USD', 'BITCOIN'),
        ('NQ=F', 'NASDAQ 100')
    ]
    
    for symbol, name in test_symbols:
        print(f"\n📊 {name}:")
        data = get_live_price(symbol)
        
        if data:
            print(f"   Price: ${data['price']}")
            print(f"   Change: {data['change']}%")
            print(f"   Volume: {data['volume']:,}")
            print(f"   Time: {data['time']}")
    
    print("\n" + "=" * 40)
    print("✅ Real-time data fetching works!")
    print("📊 Next: Add technical indicators")

if __name__ == '__main__':
    test_real_data()
