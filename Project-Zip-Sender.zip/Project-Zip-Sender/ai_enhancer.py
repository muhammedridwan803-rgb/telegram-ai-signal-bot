"""
STEP 3: AI ENHANCEMENT
Adds OpenRouter AI analysis to real technical signals
"""

import json
import aiohttp
import asyncio
from datetime import datetime
from config import OPENROUTER_API_KEY

class AIEnhancer:
    def __init__(self):
        self.api_key = OPENROUTER_API_KEY
        self.ai_enabled = bool(self.api_key)
        
        if self.ai_enabled:
            print("✅ AI Analysis: ENABLED (OpenRouter)")
        else:
            print("⚠️ AI Analysis: DISABLED (Set OPENROUTER_API_KEY in .env)")
    
    async def get_ai_analysis(self, symbol, technical_data, market_context=""):
        """Get AI analysis from OpenRouter"""
        if not self.ai_enabled:
            return {
                'ai_confidence': technical_data.get('confidence', 50),
                'ai_insight': "AI analysis not configured. Set OPENROUTER_API_KEY in .env",
                'ai_risk_assessment': technical_data.get('risk_level', 'MEDIUM'),
                'ai_suggestion': "Consider manual verification"
            }
        
        try:
            # Prepare prompt with real technical data
            prompt = f"""
            As a professional trading analyst, analyze this setup:
            
            SYMBOL: {symbol}
            CURRENT PRICE: {technical_data.get('current_price', 'N/A')}
            
            TECHNICAL INDICATORS:
            - RSI: {technical_data.get('indicators', {}).get('rsi', 'N/A')}
            - Signal: {technical_data.get('signal', 'NEUTRAL')}
            - Confidence: {technical_data.get('confidence', 0)}%
            - Volatility: {technical_data.get('indicators', {}).get('volatility', 'N/A')}%
            - Risk Level: {technical_data.get('risk_level', 'MEDIUM')}
            
            MARKET CONTEXT: {market_context}
            
            Provide concise analysis in JSON format:
            {{
                "ai_confidence": 0-100,
                "ai_insight": "2-3 sentence analysis",
                "ai_risk_assessment": "Low/Medium/High",
                "ai_suggestion": "One sentence trading suggestion",
                "key_levels": "Support/Resistance levels to watch"
            }}
            """
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://github.com/your-repo",
                "X-Title": "Trading Signal Bot"
            }
            
            data = {
                "model": "mistralai/mixtral-8x7b-instruct",
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a professional trading analyst. Be concise and practical."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "temperature": 0.3,
                "max_tokens": 300
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    "https://openrouter.ai/api/v1/chat/completions",
                    headers=headers,
                    json=data,
                    timeout=10
                ) as response:
                    
                    if response.status == 200:
                        result = await response.json()
                        content = result['choices'][0]['message']['content']
                        
                        # Extract JSON from response
                        import re
                        json_match = re.search(r'\{.*\}', content, re.DOTALL)
                        
                        if json_match:
                            ai_result = json.loads(json_match.group())
                            
                            # Ensure all fields exist
                            ai_result.setdefault('ai_confidence', technical_data.get('confidence', 50))
                            ai_result.setdefault('ai_insight', 'AI analysis completed')
                            ai_result.setdefault('ai_risk_assessment', technical_data.get('risk_level', 'MEDIUM'))
                            ai_result.setdefault('ai_suggestion', 'Consider position sizing based on risk')
                            ai_result.setdefault('key_levels', 'Watch price action')
                            
                            return ai_result
                        else:
                            return {
                                'ai_confidence': technical_data.get('confidence', 50),
                                'ai_insight': content[:150],
                                'ai_risk_assessment': technical_data.get('risk_level', 'MEDIUM'),
                                'ai_suggestion': 'AI analysis provided',
                                'key_levels': 'Not specified'
                            }
                    else:
                        error_text = await response.text()
                        print(f"❌ AI API Error {response.status}: {error_text[:100]}")
                        return None
                        
        except asyncio.TimeoutError:
            print("❌ AI request timeout")
            return None
        except Exception as e:
            print(f"❌ AI Error: {str(e)[:100]}")
            return None
    
    def combine_analysis(self, technical_data, ai_data):
        """Combine technical and AI analysis"""
        if not ai_data:
            return technical_data
        
        # Calculate combined confidence
        tech_conf = technical_data.get('confidence', 50)
        ai_conf = ai_data.get('ai_confidence', 50)
        
        # Weighted average (70% technical, 30% AI)
        combined_confidence = int((tech_conf * 0.7) + (ai_conf * 0.3))
        
        # Use AI risk assessment if available
        risk_level = ai_data.get('ai_risk_assessment') or technical_data.get('risk_level', 'MEDIUM')
        
        combined = technical_data.copy()
        combined['combined_confidence'] = combined_confidence
        combined['ai_analysis'] = ai_data
        combined['final_risk_level'] = risk_level
        
        # Final signal decision
        if combined_confidence >= 75:
            combined['final_signal'] = technical_data.get('signal', 'NEUTRAL')
            combined['signal_strength'] = 'STRONG'
        elif combined_confidence >= 60:
            combined['final_signal'] = technical_data.get('signal', 'NEUTRAL')
            combined['signal_strength'] = 'MODERATE'
        else:
            combined['final_signal'] = 'NEUTRAL'
            combined['signal_strength'] = 'WEAK'
        
        return combined

async def test_ai_enhancement():
    """Test AI enhancement with real data"""
    print("\n" + "=" * 50)
    print("🤖 TESTING AI ENHANCEMENT")
    print("=" * 50)
    
    # Import our technical analyzer
    from technical_analysis import TechnicalAnalyzer
    
    # Create instances
    analyzer = TechnicalAnalyzer()
    ai_enhancer = AIEnhancer()
    
    # Test with EUR/USD
    print("\n📈 Analyzing EUR/USD with AI...")
    
    # Get technical analysis
    technical = analyzer.analyze_symbol('EUR/USD', 'EURUSD=X')
    
    if not technical:
        print("❌ Technical analysis failed")
        return
    
    print(f"   Technical Signal: {technical['signal']} ({technical['confidence']}%)")
    
    # Get AI analysis
    ai_result = await ai_enhancer.get_ai_analysis(
        symbol='EUR/USD',
        technical_data=technical,
        market_context="London session active, medium volatility"
    )
    
    if ai_result:
        print(f"   AI Confidence: {ai_result.get('ai_confidence', 'N/A')}%")
        print(f"   AI Risk: {ai_result.get('ai_risk_assessment', 'N/A')}")
        
        # Combine analyses
        combined = ai_enhancer.combine_analysis(technical, ai_result)
        
        print(f"\n🎯 COMBINED ANALYSIS:")
        print(f"   Final Signal: {combined.get('final_signal', 'N/A')}")
        print(f"   Confidence: {combined.get('combined_confidence', 'N/A')}%")
        print(f"   Strength: {combined.get('signal_strength', 'N/A')}")
        print(f"   Risk: {combined.get('final_risk_level', 'N/A')}")
        
        if 'ai_analysis' in combined:
            print(f"\n💡 AI INSIGHT:")
            print(f"   {combined['ai_analysis'].get('ai_insight', 'No insight')[:100]}...")
        
        return combined
    else:
        print("⚠️ Using technical analysis only (AI failed)")
        return technical

if __name__ == '__main__':
    # Run async test
    result = asyncio.run(test_ai_enhancement())
    
    print("\n" + "=" * 50)
    if result:
        print("✅ AI ENHANCEMENT TEST COMPLETE")
        
        # Save sample result
        with open('sample_ai_signal.json', 'w') as f:
            json.dump(result, f, indent=2)
        print("💾 Sample saved to sample_ai_signal.json")
    else:
        print("❌ AI ENHANCEMENT TEST FAILED")
