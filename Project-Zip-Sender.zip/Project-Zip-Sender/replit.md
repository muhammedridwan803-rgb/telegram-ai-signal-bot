# AI Forex & Crypto Signal Bot

## Overview
An AI-powered Telegram bot for generating professional trading signals across Forex, Crypto, Metals, Indices, and Commodities markets.

## Features
- **AI-Powered Signals**: Technical analysis combined with AI insights
- **Professional Formatting**: BUY/SELL signals with Entry, Stop Loss, TP1/TP2/TP3
- **One-Trade-Per-Market**: Prevents overtrading by allowing only one active trade per market type
- **Live Updates**: Periodic updates on open trades (configurable interval)
- **TP/SL Tracking**: Automatic detection and AI recaps when targets are hit
- **Admin Panel**: Inline button controls for all settings

## Supported Markets
- **Forex**: EURUSD, GBPUSD, USDJPY, AUDUSD, USDCAD, etc.
- **Crypto**: BTCUSDT, ETHUSDT, SOLUSDT, BNBUSDT, etc.
- **Metals**: XAUUSD (Gold), XAGUSD (Silver)
- **Indices**: NAS100, SP500, DOW30
- **Commodities**: USOIL, NATGAS

## Commands
- `/start` - Welcome message
- `/help` - Show all commands
- `/admin` - Admin control panel (admin only)
- `/setchat` - Set current chat as signal target
- `/signal [symbol]` - Generate a trading signal
- `/analyze [symbol]` - Technical analysis only
- `/status` - View active trades

## Environment Variables
- `BOT_TOKEN` - Telegram bot token from @BotFather (required)
- `ADMIN_ID` - Your Telegram user ID for admin access (required)
- `OPENROUTER_API_KEY` - OpenRouter API key for enhanced AI (optional)

## Project Structure
- `main.py` - Main bot file with all functionality
- `config.py` - Configuration and settings management
- `technical_analysis.py` - Technical indicator calculations
- `ai_enhancer.py` - AI analysis integration
- `realtime_data.py` - Market data fetching

## Running the Bot
The bot runs via `python main.py` and uses polling for Telegram updates.

## Recent Changes
- December 2024: Complete rewrite with master prompt specifications
- Implemented one-trade-per-market rule
- Added professional signal formatting with pip calculations
- Created admin panel with inline buttons
- Added live trade updates with AI commentary
