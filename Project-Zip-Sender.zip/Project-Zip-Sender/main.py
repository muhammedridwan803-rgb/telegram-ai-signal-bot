"""
MASTER FOREX & CRYPTO SIGNAL BOT
AI-powered trading signals with professional formatting
"""

import asyncio
import json
import logging
import os
import random
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

import aiohttp
import yfinance as yf
import pandas as pd
import numpy as np
from dotenv import load_dotenv

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, Bot
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, 
    ContextTypes, JobQueue
)

load_dotenv()

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.getenv('BOT_TOKEN')
ADMIN_ID = os.getenv('ADMIN_ID')
OPENROUTER_API_KEY = os.getenv('OPENROUTER_API_KEY', '')

SETTINGS_FILE = 'bot_settings.json'
TRADES_FILE = 'active_trades.json'
HISTORY_FILE = 'trade_history.json'


class MarketDataProvider:
    """Real-time market data from Yahoo Finance"""
    
    SYMBOLS = {
        'forex': {
            'EURUSD': 'EURUSD=X', 'GBPUSD': 'GBPUSD=X', 'USDJPY': 'JPY=X',
            'AUDUSD': 'AUDUSD=X', 'USDCAD': 'CAD=X', 'USDCHF': 'CHF=X',
            'NZDUSD': 'NZDUSD=X', 'EURGBP': 'EURGBP=X', 'EURJPY': 'EURJPY=X'
        },
        'crypto': {
            'BTCUSDT': 'BTC-USD', 'ETHUSDT': 'ETH-USD', 'SOLUSDT': 'SOL-USD',
            'BNBUSDT': 'BNB-USD', 'XRPUSDT': 'XRP-USD', 'ADAUSDT': 'ADA-USD'
        },
        'metals': {
            'XAUUSD': 'GC=F', 'XAGUSD': 'SI=F', 'COPPER': 'HG=F'
        },
        'indices': {
            'NAS100': 'NQ=F', 'SP500': 'ES=F', 'DOW30': 'YM=F', 'DAX': '^GDAXI'
        },
        'commodities': {
            'USOIL': 'CL=F', 'UKOIL': 'BZ=F', 'NATGAS': 'NG=F'
        }
    }
    
    PIP_SIZES = {
        'forex': 0.0001,
        'crypto': 1.0,
        'metals': 0.01,
        'indices': 1.0,
        'commodities': 0.01
    }
    
    @classmethod
    def get_market_type(cls, symbol: str) -> str:
        symbol = symbol.upper().replace('/', '')
        for market_type, symbols in cls.SYMBOLS.items():
            if symbol in symbols:
                return market_type
        return 'forex'
    
    @classmethod
    def get_yf_symbol(cls, symbol: str) -> Optional[str]:
        symbol = symbol.upper().replace('/', '')
        for market_type, symbols in cls.SYMBOLS.items():
            if symbol in symbols:
                return symbols[symbol]
        return None
    
    @classmethod
    def get_pip_size(cls, symbol: str) -> float:
        market_type = cls.get_market_type(symbol)
        return cls.PIP_SIZES.get(market_type, 0.0001)
    
    @classmethod
    async def get_price(cls, symbol: str) -> Optional[Dict]:
        try:
            yf_symbol = cls.get_yf_symbol(symbol)
            if not yf_symbol:
                return None
            
            ticker = yf.Ticker(yf_symbol)
            data = ticker.history(period='2d', interval='5m')
            
            if data.empty or len(data) < 10:
                return None
            
            current = data.iloc[-1]
            prev = data.iloc[-2]
            
            return {
                'symbol': symbol,
                'price': round(float(current['Close']), 5),
                'high': round(float(current['High']), 5),
                'low': round(float(current['Low']), 5),
                'change_pct': round(((current['Close'] - prev['Close']) / prev['Close']) * 100, 2),
                'volume': int(current['Volume']),
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Price fetch error for {symbol}: {e}")
            return None


class TechnicalAnalyzer:
    """Technical analysis engine"""
    
    @staticmethod
    async def analyze(symbol: str) -> Optional[Dict]:
        try:
            yf_symbol = MarketDataProvider.get_yf_symbol(symbol)
            if not yf_symbol:
                return None
            
            ticker = yf.Ticker(yf_symbol)
            data = ticker.history(period='5d', interval='15m')
            
            if len(data) < 50:
                return None
            
            df = data.copy()
            current_price = float(df['Close'].iloc[-1])
            
            delta = df['Close'].diff()
            gain = delta.where(delta > 0, 0).rolling(window=14).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
            rs = gain / loss
            rsi = 100 - (100 / (1 + rs))
            current_rsi = float(rsi.iloc[-1]) if not pd.isna(rsi.iloc[-1]) else 50
            
            ema12 = df['Close'].ewm(span=12, adjust=False).mean()
            ema26 = df['Close'].ewm(span=26, adjust=False).mean()
            macd = ema12 - ema26
            signal_line = macd.ewm(span=9, adjust=False).mean()
            macd_histogram = float((macd - signal_line).iloc[-1])
            
            sma_20 = float(df['Close'].rolling(window=20).mean().iloc[-1])
            sma_50 = float(df['Close'].rolling(window=50).mean().iloc[-1])
            
            bb_middle = df['Close'].rolling(window=20).mean()
            bb_std = df['Close'].rolling(window=20).std()
            bb_upper = float((bb_middle + (bb_std * 2)).iloc[-1])
            bb_lower = float((bb_middle - (bb_std * 2)).iloc[-1])
            
            support = float(df['Low'].tail(20).min())
            resistance = float(df['High'].tail(20).max())
            
            atr = df['High'].tail(14).max() - df['Low'].tail(14).min()
            volatility = float((atr / current_price) * 100)
            
            signal_score = 0
            
            if current_rsi < 30:
                signal_score += 25
            elif current_rsi > 70:
                signal_score -= 25
            elif current_rsi < 45:
                signal_score += 10
            elif current_rsi > 55:
                signal_score -= 10
            
            if macd_histogram > 0:
                signal_score += 20
            else:
                signal_score -= 20
            
            if current_price > sma_20 > sma_50:
                signal_score += 15
            elif current_price < sma_20 < sma_50:
                signal_score -= 15
            
            bb_position = (current_price - bb_lower) / (bb_upper - bb_lower) if bb_upper != bb_lower else 0.5
            if bb_position < 0.2:
                signal_score += 10
            elif bb_position > 0.8:
                signal_score -= 10
            
            if signal_score >= 20:
                signal = "BUY"
                confidence = min(50 + signal_score, 95)
            elif signal_score <= -20:
                signal = "SELL"
                confidence = min(50 + abs(signal_score), 95)
            else:
                signal = "NEUTRAL"
                confidence = 50
            
            return {
                'symbol': symbol,
                'current_price': current_price,
                'signal': signal,
                'confidence': confidence,
                'rsi': round(current_rsi, 1),
                'macd_histogram': round(macd_histogram, 5),
                'sma_20': round(sma_20, 5),
                'sma_50': round(sma_50, 5),
                'bb_upper': round(bb_upper, 5),
                'bb_lower': round(bb_lower, 5),
                'support': round(support, 5),
                'resistance': round(resistance, 5),
                'volatility': round(volatility, 2),
                'trend': 'BULLISH' if current_price > sma_20 else 'BEARISH',
                'momentum': 'STRONG' if abs(macd_histogram) > 0.001 else 'WEAK'
            }
        except Exception as e:
            logger.error(f"Technical analysis error for {symbol}: {e}")
            return None


class AIAnalyzer:
    """AI-powered market analysis using OpenRouter"""
    
    def __init__(self):
        self.api_key = OPENROUTER_API_KEY
        self.enabled = bool(self.api_key)
    
    async def get_ai_hype(self, symbol: str, direction: str, rr_ratio: float, technical: Dict) -> str:
        if rr_ratio >= 2.5:
            tone = "high conviction"
        elif rr_ratio >= 1.8:
            tone = "confident"
        else:
            tone = "calm"
        
        hype_templates = {
            "high conviction": [
                f"Strong structural confluence aligning with momentum shift.\nPrice action confirms directional bias with clear invalidation.",
                f"Multiple timeframe alignment detected with high-probability setup.\nRisk parameters favor aggressive positioning.",
                f"Institutional order flow suggests continuation bias.\nKey liquidity zones identified for optimal entry."
            ],
            "confident": [
                f"Technical alignment supports the directional thesis.\nMonitoring key levels for confirmation.",
                f"Price structure showing favorable risk-reward dynamics.\nVolatility conditions conducive to the setup.",
                f"Trend continuation pattern identified with defined risk.\nMomentum indicators confirm directional bias."
            ],
            "calm": [
                f"Setup meets minimum criteria for consideration.\nRisk management paramount at current levels.",
                f"Technical factors align for potential opportunity.\nPatience required for optimal execution.",
                f"Market structure provides defined entry parameters.\nPosition sizing adjusted for current conditions."
            ]
        }
        
        return random.choice(hype_templates[tone])
    
    async def get_technical_commentary(self, technical: Dict) -> List[str]:
        commentary = []
        
        if technical['trend'] == 'BULLISH':
            commentary.append(f"Trend: Price trading above key moving averages, bullish structure intact")
        else:
            commentary.append(f"Trend: Price below moving averages, bearish pressure dominant")
        
        if technical['rsi'] < 35:
            commentary.append(f"Structure: RSI at {technical['rsi']}, oversold conditions present")
        elif technical['rsi'] > 65:
            commentary.append(f"Structure: RSI at {technical['rsi']}, overbought territory reached")
        else:
            commentary.append(f"Structure: RSI at {technical['rsi']}, neutral momentum zone")
        
        if technical['momentum'] == 'STRONG':
            commentary.append(f"Momentum: MACD histogram expanding, trend strength confirmed")
        else:
            commentary.append(f"Momentum: MACD showing consolidation, await breakout confirmation")
        
        if technical['volatility'] > 2:
            commentary.append(f"Volatility: Elevated at {technical['volatility']}%, wider stops recommended")
        else:
            commentary.append(f"Volatility: Low at {technical['volatility']}%, tight risk parameters viable")
        
        return commentary[:4]
    
    async def get_tp_sl_recap(self, event_type: str, symbol: str, technical: Dict) -> List[str]:
        if event_type == 'TP':
            recaps = [
                "Momentum carried price through target zone as anticipated",
                "Structural break triggered continuation toward profit level",
                "Volatility expansion pushed price beyond resistance/support",
                "Liquidity sweep above/below key level completed the move"
            ]
        else:
            recaps = [
                "Counter-trend momentum invalidated the setup thesis",
                "Structural shift triggered stop-loss protection",
                "Unexpected volatility spike caused adverse price movement",
                "Liquidity hunt below/above entry resulted in position exit"
            ]
        
        random.shuffle(recaps)
        return recaps[:4]


class TradeManager:
    """Manages active trades and enforces one-trade-per-market rule"""
    
    def __init__(self):
        self.active_trades: Dict[str, Dict] = {}
        self.trade_history: List[Dict] = []
        self.load_trades()
    
    def load_trades(self):
        try:
            if os.path.exists(TRADES_FILE):
                with open(TRADES_FILE, 'r') as f:
                    self.active_trades = json.load(f)
            if os.path.exists(HISTORY_FILE):
                with open(HISTORY_FILE, 'r') as f:
                    self.trade_history = json.load(f)
        except Exception as e:
            logger.error(f"Error loading trades: {e}")
    
    def save_trades(self):
        try:
            with open(TRADES_FILE, 'w') as f:
                json.dump(self.active_trades, f, indent=2)
            with open(HISTORY_FILE, 'w') as f:
                json.dump(self.trade_history[-100:], f, indent=2)
        except Exception as e:
            logger.error(f"Error saving trades: {e}")
    
    def can_open_trade(self, market_type: str) -> tuple[bool, str]:
        for trade_id, trade in self.active_trades.items():
            if trade.get('market_type') == market_type and trade.get('status') == 'OPEN':
                return False, f"Active {market_type} trade exists: {trade.get('symbol')}"
        return True, "OK"
    
    def open_trade(self, trade_data: Dict) -> str:
        trade_id = f"{trade_data['symbol']}_{int(datetime.now().timestamp())}"
        trade_data['id'] = trade_id
        trade_data['status'] = 'OPEN'
        trade_data['opened_at'] = datetime.now().isoformat()
        trade_data['tp_hits'] = []
        self.active_trades[trade_id] = trade_data
        self.save_trades()
        return trade_id
    
    def close_trade(self, trade_id: str, reason: str, final_price: float):
        if trade_id in self.active_trades:
            trade = self.active_trades[trade_id]
            trade['status'] = 'CLOSED'
            trade['closed_at'] = datetime.now().isoformat()
            trade['close_reason'] = reason
            trade['final_price'] = final_price
            self.trade_history.append(trade)
            del self.active_trades[trade_id]
            self.save_trades()
    
    def hit_tp(self, trade_id: str, tp_level: int, price: float):
        if trade_id in self.active_trades:
            self.active_trades[trade_id]['tp_hits'].append({
                'level': tp_level,
                'price': price,
                'time': datetime.now().isoformat()
            })
            if tp_level == 3:
                self.close_trade(trade_id, 'TP3_HIT', price)
            else:
                self.save_trades()
    
    def get_active_trades(self) -> List[Dict]:
        return [t for t in self.active_trades.values() if t.get('status') == 'OPEN']


class SettingsManager:
    """Bot settings management"""
    
    DEFAULT_SETTINGS = {
        'auto_signals_enabled': True,
        'live_updates_enabled': True,
        'update_interval_minutes': 15,
        'max_signals_per_day': 6,
        'min_confidence': 75,
        'min_rr_ratio': 1.5,
        'target_chat_id': None,
        'target_topic_id': None,
        'signals_today': 0,
        'last_reset': None
    }
    
    def __init__(self):
        self.settings = self.load_settings()
    
    def load_settings(self) -> Dict:
        try:
            if os.path.exists(SETTINGS_FILE):
                with open(SETTINGS_FILE, 'r') as f:
                    settings = json.load(f)
                    for key, value in self.DEFAULT_SETTINGS.items():
                        if key not in settings:
                            settings[key] = value
                    return settings
        except Exception as e:
            logger.error(f"Error loading settings: {e}")
        return self.DEFAULT_SETTINGS.copy()
    
    def save_settings(self):
        try:
            with open(SETTINGS_FILE, 'w') as f:
                json.dump(self.settings, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving settings: {e}")
    
    def get(self, key: str, default=None):
        return self.settings.get(key, default)
    
    def set(self, key: str, value):
        self.settings[key] = value
        self.save_settings()
    
    def reset_daily_counters(self):
        today = datetime.now().date().isoformat()
        if self.settings.get('last_reset') != today:
            self.settings['signals_today'] = 0
            self.settings['last_reset'] = today
            self.save_settings()


class SignalFormatter:
    """Professional signal message formatting per master prompt"""
    
    @staticmethod
    def format_signal(
        symbol: str,
        direction: str,
        live_price: float,
        entry: float,
        stop_loss: float,
        tp1: float,
        tp2: float,
        tp3: float,
        market_type: str,
        ai_hype: str,
        technical_commentary: List[str],
        pip_size: float
    ) -> str:
        direction_header = "🟩 BUY" if direction == "BUY" else "🟥 SELL"
        
        if direction == "BUY":
            sl_pips = abs(entry - stop_loss) / pip_size
            tp1_pips = abs(tp1 - entry) / pip_size
            tp2_pips = abs(tp2 - entry) / pip_size
            tp3_pips = abs(tp3 - entry) / pip_size
        else:
            sl_pips = abs(stop_loss - entry) / pip_size
            tp1_pips = abs(entry - tp1) / pip_size
            tp2_pips = abs(entry - tp2) / pip_size
            tp3_pips = abs(entry - tp3) / pip_size
        
        rr1 = round(tp1_pips / sl_pips, 2) if sl_pips > 0 else 0
        rr2 = round(tp2_pips / sl_pips, 2) if sl_pips > 0 else 0
        rr3 = round(tp3_pips / sl_pips, 2) if sl_pips > 0 else 0
        
        msg = f"{direction_header}\n"
        msg += "━" * 32 + "\n\n"
        msg += f"📊 **{symbol}**\n\n"
        
        msg += f"💰 **Live Price:** `{live_price:.5f}`\n"
        msg += f"📍 **Entry:** `{entry:.5f}`\n"
        msg += f"🛑 **Stop Loss:** `{stop_loss:.5f}` ({sl_pips:.1f} pips)\n\n"
        
        msg += f"🎯 **TP1:** `{tp1:.5f}` ({tp1_pips:.1f} pips) — RR 1:{rr1}\n"
        msg += f"🎯 **TP2:** `{tp2:.5f}` ({tp2_pips:.1f} pips) — RR 1:{rr2}\n"
        msg += f"🎯 **TP3:** `{tp3:.5f}` ({tp3_pips:.1f} pips) — RR 1:{rr3}\n\n"
        
        msg += f"📈 **Market:** {market_type.upper()}\n\n"
        
        msg += "━" * 32 + "\n"
        msg += "**AI Analysis:**\n"
        msg += f"{ai_hype}\n\n"
        
        msg += "**Technical Commentary:**\n"
        for comment in technical_commentary:
            msg += f"• {comment}\n"
        
        msg += "\n" + "━" * 32 + "\n"
        msg += f"⏰ {datetime.now().strftime('%H:%M UTC — %d %b %Y')}\n\n"
        msg += "⚠️ This is not financial advice. Trade responsibly and manage your risk."
        
        return msg
    
    @staticmethod
    def format_live_update(
        trade: Dict,
        current_price: float,
        ai_commentary: List[str]
    ) -> str:
        direction = trade.get('direction', 'BUY')
        direction_header = "🟩 LONG UPDATE" if direction == "BUY" else "🟥 SHORT UPDATE"
        
        symbol = trade['symbol']
        entry = trade['entry']
        sl = trade['stop_loss']
        tp1 = trade['tp1']
        tp2 = trade['tp2']
        tp3 = trade['tp3']
        
        if direction == "BUY":
            dist_tp1 = current_price - tp1
            dist_tp2 = current_price - tp2
            dist_tp3 = current_price - tp3
            dist_sl = current_price - sl
            pnl_pips = (current_price - entry) / trade.get('pip_size', 0.0001)
        else:
            dist_tp1 = tp1 - current_price
            dist_tp2 = tp2 - current_price
            dist_tp3 = tp3 - current_price
            dist_sl = sl - current_price
            pnl_pips = (entry - current_price) / trade.get('pip_size', 0.0001)
        
        opened_at = datetime.fromisoformat(trade['opened_at'])
        time_open = datetime.now() - opened_at
        hours, remainder = divmod(int(time_open.total_seconds()), 3600)
        minutes, _ = divmod(remainder, 60)
        
        status = "IN PROFIT" if pnl_pips > 0 else "IN DRAWDOWN"
        
        msg = f"{direction_header}\n"
        msg += "━" * 32 + "\n\n"
        msg += f"📊 **{symbol}** — {status}\n\n"
        
        msg += f"💰 **Live Price:** `{current_price:.5f}`\n"
        msg += f"📍 **Entry:** `{entry:.5f}`\n"
        msg += f"📊 **P/L:** {pnl_pips:+.1f} pips\n\n"
        
        tp_hits = trade.get('tp_hits', [])
        tp1_status = "✅" if any(h['level'] == 1 for h in tp_hits) else "⏳"
        tp2_status = "✅" if any(h['level'] == 2 for h in tp_hits) else "⏳"
        tp3_status = "✅" if any(h['level'] == 3 for h in tp_hits) else "⏳"
        
        msg += f"{tp1_status} **TP1:** {abs(dist_tp1):.5f} away\n"
        msg += f"{tp2_status} **TP2:** {abs(dist_tp2):.5f} away\n"
        msg += f"{tp3_status} **TP3:** {abs(dist_tp3):.5f} away\n"
        msg += f"🛑 **SL:** {abs(dist_sl):.5f} away\n\n"
        
        msg += f"⏱️ **Time Open:** {hours}h {minutes}m\n\n"
        
        msg += "**AI Commentary:**\n"
        for comment in ai_commentary[:2]:
            msg += f"• {comment}\n"
        
        msg += "\n⚠️ This is not financial advice. Trade responsibly and manage your risk."
        
        return msg
    
    @staticmethod
    def format_tp_sl_message(
        trade: Dict,
        event_type: str,
        level: int,
        price: float,
        recap: List[str]
    ) -> str:
        symbol = trade['symbol']
        direction = trade.get('direction', 'BUY')
        
        if event_type == 'TP':
            header = f"🎯 TP{level} HIT"
            emoji = "✅"
        else:
            header = "🛑 STOP LOSS HIT"
            emoji = "❌"
        
        msg = f"{header}\n"
        msg += "━" * 32 + "\n\n"
        msg += f"📊 **{symbol}** — {'LONG' if direction == 'BUY' else 'SHORT'}\n\n"
        
        msg += f"📍 **Entry:** `{trade['entry']:.5f}`\n"
        msg += f"{emoji} **Exit:** `{price:.5f}`\n\n"
        
        pnl = abs(price - trade['entry']) / trade.get('pip_size', 0.0001)
        if event_type == 'TP':
            msg += f"💰 **Result:** +{pnl:.1f} pips\n\n"
        else:
            msg += f"💸 **Result:** -{pnl:.1f} pips\n\n"
        
        msg += "**AI Recap:**\n"
        for point in recap[:4]:
            msg += f"• {point}\n"
        
        msg += "\n⚠️ This is not financial advice. Trade responsibly and manage your risk."
        
        return msg


class ForexSignalBot:
    """Main bot class"""
    
    def __init__(self):
        self.settings = SettingsManager()
        self.trade_manager = TradeManager()
        self.ai_analyzer = AIAnalyzer()
        self.application = None
        self.bot = None
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text(
            "🤖 **AI FOREX & CRYPTO SIGNAL BOT**\n\n"
            "Welcome! I provide AI-powered trading signals for:\n"
            "• Forex pairs\n"
            "• Crypto futures/spot\n"
            "• Metals (Gold, Silver)\n"
            "• Indices\n"
            "• Commodities\n\n"
            "**Commands:**\n"
            "/admin - Open admin panel\n"
            "/signal [symbol] - Generate signal\n"
            "/status - View active trades\n"
            "/help - Show all commands\n\n"
            "⚠️ Educational purposes only. Not financial advice.",
            parse_mode='Markdown'
        )
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text(
            "📋 **AVAILABLE COMMANDS**\n\n"
            "**Signals:**\n"
            "/signal [symbol] - Generate a signal (e.g., /signal EURUSD)\n"
            "/analyze [symbol] - Technical analysis only\n\n"
            "**Trading:**\n"
            "/status - View all active trades\n"
            "/close [trade_id] - Close a trade manually\n\n"
            "**Admin (Admin Only):**\n"
            "/admin - Open admin control panel\n"
            "/setchat - Set this chat for signals\n"
            "/broadcast [message] - Send message to signal chat\n\n"
            "**Supported Markets:**\n"
            "Forex: EURUSD, GBPUSD, USDJPY, etc.\n"
            "Crypto: BTCUSDT, ETHUSDT, SOLUSDT, etc.\n"
            "Metals: XAUUSD, XAGUSD\n"
            "Indices: NAS100, SP500, DOW30\n"
            "Commodities: USOIL, NATGAS",
            parse_mode='Markdown'
        )
    
    async def admin_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = str(update.effective_user.id)
        if user_id != ADMIN_ID:
            await update.message.reply_text("❌ Admin access only.")
            return
        
        keyboard = [
            [
                InlineKeyboardButton(
                    f"{'✅' if self.settings.get('auto_signals_enabled') else '❌'} Auto Signals",
                    callback_data='toggle_auto_signals'
                ),
                InlineKeyboardButton(
                    f"{'✅' if self.settings.get('live_updates_enabled') else '❌'} Live Updates",
                    callback_data='toggle_live_updates'
                )
            ],
            [
                InlineKeyboardButton(
                    f"⏱️ Update: {self.settings.get('update_interval_minutes')}min",
                    callback_data='change_interval'
                ),
                InlineKeyboardButton(
                    f"📊 Max: {self.settings.get('max_signals_per_day')}/day",
                    callback_data='change_max_signals'
                )
            ],
            [
                InlineKeyboardButton("🎯 Set Target Chat", callback_data='set_target'),
                InlineKeyboardButton("🔄 Reset Counters", callback_data='reset_counters')
            ],
            [
                InlineKeyboardButton("📈 View Stats", callback_data='view_stats'),
                InlineKeyboardButton("🗑️ Clear Trades", callback_data='clear_trades')
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        target_chat = self.settings.get('target_chat_id')
        chat_status = f"Chat: {target_chat}" if target_chat else "Chat: Not set"
        
        await update.message.reply_text(
            "⚙️ **ADMIN CONTROL PANEL**\n\n"
            f"📡 Signals Today: {self.settings.get('signals_today', 0)}\n"
            f"📊 Active Trades: {len(self.trade_manager.get_active_trades())}\n"
            f"🎯 {chat_status}\n\n"
            "Use buttons below to configure:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
    
    async def callback_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        user_id = str(query.from_user.id)
        
        if user_id != ADMIN_ID:
            await query.answer("Admin access only!", show_alert=True)
            return
        
        await query.answer()
        
        data = query.data
        
        if data == 'toggle_auto_signals':
            current = self.settings.get('auto_signals_enabled')
            self.settings.set('auto_signals_enabled', not current)
            status = "enabled" if not current else "disabled"
            await query.edit_message_text(f"✅ Auto signals {status}. Use /admin to see panel.")
            
        elif data == 'toggle_live_updates':
            current = self.settings.get('live_updates_enabled')
            self.settings.set('live_updates_enabled', not current)
            status = "enabled" if not current else "disabled"
            await query.edit_message_text(f"✅ Live updates {status}. Use /admin to see panel.")
            
        elif data == 'change_interval':
            intervals = [5, 10, 15, 30, 60]
            current = self.settings.get('update_interval_minutes', 15)
            idx = intervals.index(current) if current in intervals else 2
            new_interval = intervals[(idx + 1) % len(intervals)]
            self.settings.set('update_interval_minutes', new_interval)
            await query.edit_message_text(f"✅ Update interval set to {new_interval} minutes. Use /admin to see panel.")
            
        elif data == 'change_max_signals':
            limits = [3, 5, 6, 10, 15]
            current = self.settings.get('max_signals_per_day', 6)
            idx = limits.index(current) if current in limits else 2
            new_limit = limits[(idx + 1) % len(limits)]
            self.settings.set('max_signals_per_day', new_limit)
            await query.edit_message_text(f"✅ Max signals set to {new_limit}/day. Use /admin to see panel.")
            
        elif data == 'set_target':
            chat_id = str(query.message.chat.id)
            topic_id = query.message.message_thread_id
            self.settings.set('target_chat_id', chat_id)
            self.settings.set('target_topic_id', topic_id)
            await query.edit_message_text(f"✅ Target chat set to this chat. Signals will be posted here.")
            
        elif data == 'reset_counters':
            self.settings.set('signals_today', 0)
            await query.edit_message_text("✅ Daily counters reset. Use /admin to see panel.")
            
        elif data == 'view_stats':
            trades = self.trade_manager.get_active_trades()
            history = self.trade_manager.trade_history[-10:]
            
            stats = f"📊 **BOT STATISTICS**\n\n"
            stats += f"Active Trades: {len(trades)}\n"
            stats += f"Signals Today: {self.settings.get('signals_today', 0)}\n"
            stats += f"Total History: {len(self.trade_manager.trade_history)}\n\n"
            
            if trades:
                stats += "**Active Trades:**\n"
                for t in trades:
                    stats += f"• {t['symbol']} {t['direction']}\n"
            
            await query.edit_message_text(stats, parse_mode='Markdown')
            
        elif data == 'clear_trades':
            self.trade_manager.active_trades = {}
            self.trade_manager.save_trades()
            await query.edit_message_text("✅ All active trades cleared. Use /admin to see panel.")
    
    async def setchat_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = str(update.effective_user.id)
        if user_id != ADMIN_ID:
            await update.message.reply_text("❌ Admin access only.")
            return
        
        chat_id = str(update.effective_chat.id)
        topic_id = update.message.message_thread_id
        
        self.settings.set('target_chat_id', chat_id)
        self.settings.set('target_topic_id', topic_id)
        
        await update.message.reply_text(
            f"✅ **Signal Target Set**\n\n"
            f"Chat ID: `{chat_id}`\n"
            f"Topic ID: `{topic_id or 'None'}`\n\n"
            "Signals will be posted here.",
            parse_mode='Markdown'
        )
    
    async def signal_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not context.args:
            await update.message.reply_text(
                "Please specify a symbol.\n"
                "Usage: `/signal EURUSD`\n\n"
                "Supported: EURUSD, GBPUSD, BTCUSDT, XAUUSD, etc.",
                parse_mode='Markdown'
            )
            return
        
        symbol = context.args[0].upper().replace('/', '')
        market_type = MarketDataProvider.get_market_type(symbol)
        
        can_trade, reason = self.trade_manager.can_open_trade(market_type)
        if not can_trade:
            await update.message.reply_text(f"❌ Cannot open trade: {reason}")
            return
        
        await update.message.reply_text(f"🔄 Analyzing {symbol}...")
        
        technical = await TechnicalAnalyzer.analyze(symbol)
        if not technical:
            await update.message.reply_text(f"❌ Could not analyze {symbol}. Check symbol or try again.")
            return
        
        if technical['signal'] == 'NEUTRAL':
            await update.message.reply_text(
                f"📊 **{symbol} Analysis**\n\n"
                f"Signal: NEUTRAL (No clear direction)\n"
                f"RSI: {technical['rsi']}\n"
                f"Trend: {technical['trend']}\n\n"
                "No signal generated due to insufficient conviction.",
                parse_mode='Markdown'
            )
            return
        
        price_data = await MarketDataProvider.get_price(symbol)
        if not price_data:
            await update.message.reply_text("❌ Could not fetch live price.")
            return
        
        current_price = price_data['price']
        pip_size = MarketDataProvider.get_pip_size(symbol)
        volatility_factor = technical['volatility'] / 100
        
        if technical['signal'] == 'BUY':
            entry = current_price * 1.0001
            sl_distance = current_price * max(0.005, volatility_factor * 0.5)
            stop_loss = current_price - sl_distance
            tp1 = current_price + (sl_distance * 1.5)
            tp2 = current_price + (sl_distance * 2.0)
            tp3 = current_price + (sl_distance * 3.0)
        else:
            entry = current_price * 0.9999
            sl_distance = current_price * max(0.005, volatility_factor * 0.5)
            stop_loss = current_price + sl_distance
            tp1 = current_price - (sl_distance * 1.5)
            tp2 = current_price - (sl_distance * 2.0)
            tp3 = current_price - (sl_distance * 3.0)
        
        rr_ratio = 1.5
        ai_hype = await self.ai_analyzer.get_ai_hype(symbol, technical['signal'], rr_ratio, technical)
        commentary = await self.ai_analyzer.get_technical_commentary(technical)
        
        message = SignalFormatter.format_signal(
            symbol=symbol,
            direction=technical['signal'],
            live_price=current_price,
            entry=entry,
            stop_loss=stop_loss,
            tp1=tp1,
            tp2=tp2,
            tp3=tp3,
            market_type=market_type,
            ai_hype=ai_hype,
            technical_commentary=commentary,
            pip_size=pip_size
        )
        
        trade_data = {
            'symbol': symbol,
            'direction': technical['signal'],
            'market_type': market_type,
            'entry': entry,
            'stop_loss': stop_loss,
            'tp1': tp1,
            'tp2': tp2,
            'tp3': tp3,
            'pip_size': pip_size,
            'confidence': technical['confidence']
        }
        trade_id = self.trade_manager.open_trade(trade_data)
        
        self.settings.set('signals_today', self.settings.get('signals_today', 0) + 1)
        
        await update.message.reply_text(message, parse_mode='Markdown')
        
        target_chat = self.settings.get('target_chat_id')
        if target_chat and str(update.effective_chat.id) != target_chat:
            try:
                topic_id = self.settings.get('target_topic_id')
                await context.bot.send_message(
                    chat_id=target_chat,
                    message_thread_id=topic_id,
                    text=message,
                    parse_mode='Markdown'
                )
            except Exception as e:
                logger.error(f"Failed to send to target chat: {e}")
    
    async def analyze_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not context.args:
            await update.message.reply_text("Usage: /analyze EURUSD")
            return
        
        symbol = context.args[0].upper().replace('/', '')
        
        await update.message.reply_text(f"🔄 Analyzing {symbol}...")
        
        technical = await TechnicalAnalyzer.analyze(symbol)
        if not technical:
            await update.message.reply_text(f"❌ Could not analyze {symbol}.")
            return
        
        msg = f"📊 **{symbol} TECHNICAL ANALYSIS**\n\n"
        msg += f"💰 Price: `{technical['current_price']:.5f}`\n"
        msg += f"📈 Signal: **{technical['signal']}** ({technical['confidence']}%)\n\n"
        msg += f"**Indicators:**\n"
        msg += f"• RSI: {technical['rsi']}\n"
        msg += f"• Trend: {technical['trend']}\n"
        msg += f"• Momentum: {technical['momentum']}\n"
        msg += f"• Volatility: {technical['volatility']}%\n\n"
        msg += f"**Levels:**\n"
        msg += f"• Support: {technical['support']:.5f}\n"
        msg += f"• Resistance: {technical['resistance']:.5f}\n"
        msg += f"• SMA 20: {technical['sma_20']:.5f}\n"
        msg += f"• SMA 50: {technical['sma_50']:.5f}\n"
        
        await update.message.reply_text(msg, parse_mode='Markdown')
    
    async def status_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        trades = self.trade_manager.get_active_trades()
        
        if not trades:
            await update.message.reply_text("📊 No active trades currently.")
            return
        
        msg = f"📊 **ACTIVE TRADES** ({len(trades)})\n\n"
        
        for trade in trades:
            price_data = await MarketDataProvider.get_price(trade['symbol'])
            current_price = price_data['price'] if price_data else trade['entry']
            
            if trade['direction'] == 'BUY':
                pnl = (current_price - trade['entry']) / trade.get('pip_size', 0.0001)
            else:
                pnl = (trade['entry'] - current_price) / trade.get('pip_size', 0.0001)
            
            status_emoji = "🟢" if pnl > 0 else "🔴"
            
            msg += f"{status_emoji} **{trade['symbol']}** {trade['direction']}\n"
            msg += f"   Entry: {trade['entry']:.5f}\n"
            msg += f"   Current: {current_price:.5f}\n"
            msg += f"   P/L: {pnl:+.1f} pips\n\n"
        
        await update.message.reply_text(msg, parse_mode='Markdown')
    
    async def live_update_job(self, context: ContextTypes.DEFAULT_TYPE):
        if not self.settings.get('live_updates_enabled'):
            return
        
        trades = self.trade_manager.get_active_trades()
        if not trades:
            return
        
        target_chat = self.settings.get('target_chat_id')
        if not target_chat:
            return
        
        for trade in trades:
            try:
                price_data = await MarketDataProvider.get_price(trade['symbol'])
                if not price_data:
                    continue
                
                current_price = price_data['price']
                
                if trade['direction'] == 'BUY':
                    if current_price <= trade['stop_loss']:
                        recap = await self.ai_analyzer.get_tp_sl_recap('SL', trade['symbol'], {})
                        message = SignalFormatter.format_tp_sl_message(trade, 'SL', 0, current_price, recap)
                        self.trade_manager.close_trade(trade['id'], 'SL_HIT', current_price)
                        await context.bot.send_message(chat_id=target_chat, text=message, parse_mode='Markdown')
                        continue
                    
                    tp_hits = [h['level'] for h in trade.get('tp_hits', [])]
                    if current_price >= trade['tp3'] and 3 not in tp_hits:
                        recap = await self.ai_analyzer.get_tp_sl_recap('TP', trade['symbol'], {})
                        message = SignalFormatter.format_tp_sl_message(trade, 'TP', 3, current_price, recap)
                        self.trade_manager.hit_tp(trade['id'], 3, current_price)
                        await context.bot.send_message(chat_id=target_chat, text=message, parse_mode='Markdown')
                        continue
                    elif current_price >= trade['tp2'] and 2 not in tp_hits:
                        self.trade_manager.hit_tp(trade['id'], 2, current_price)
                    elif current_price >= trade['tp1'] and 1 not in tp_hits:
                        self.trade_manager.hit_tp(trade['id'], 1, current_price)
                else:
                    if current_price >= trade['stop_loss']:
                        recap = await self.ai_analyzer.get_tp_sl_recap('SL', trade['symbol'], {})
                        message = SignalFormatter.format_tp_sl_message(trade, 'SL', 0, current_price, recap)
                        self.trade_manager.close_trade(trade['id'], 'SL_HIT', current_price)
                        await context.bot.send_message(chat_id=target_chat, text=message, parse_mode='Markdown')
                        continue
                    
                    tp_hits = [h['level'] for h in trade.get('tp_hits', [])]
                    if current_price <= trade['tp3'] and 3 not in tp_hits:
                        recap = await self.ai_analyzer.get_tp_sl_recap('TP', trade['symbol'], {})
                        message = SignalFormatter.format_tp_sl_message(trade, 'TP', 3, current_price, recap)
                        self.trade_manager.hit_tp(trade['id'], 3, current_price)
                        await context.bot.send_message(chat_id=target_chat, text=message, parse_mode='Markdown')
                        continue
                    elif current_price <= trade['tp2'] and 2 not in tp_hits:
                        self.trade_manager.hit_tp(trade['id'], 2, current_price)
                    elif current_price <= trade['tp1'] and 1 not in tp_hits:
                        self.trade_manager.hit_tp(trade['id'], 1, current_price)
                
                ai_commentary = [
                    f"Price action {'favoring' if (current_price > trade['entry'] if trade['direction'] == 'BUY' else current_price < trade['entry']) else 'against'} position",
                    f"Monitoring key levels for continuation or reversal signals"
                ]
                
                message = SignalFormatter.format_live_update(trade, current_price, ai_commentary)
                
                topic_id = self.settings.get('target_topic_id')
                await context.bot.send_message(
                    chat_id=target_chat,
                    message_thread_id=topic_id,
                    text=message,
                    parse_mode='Markdown'
                )
                
            except Exception as e:
                logger.error(f"Error in live update for {trade['symbol']}: {e}")
    
    def run(self):
        if not BOT_TOKEN:
            print("❌ ERROR: BOT_TOKEN not found!")
            print("Please set BOT_TOKEN in your environment variables or .env file")
            return
        
        print("=" * 50)
        print("🤖 AI FOREX & CRYPTO SIGNAL BOT")
        print("=" * 50)
        print(f"✅ Bot Token: {'Configured' if BOT_TOKEN else 'Missing'}")
        print(f"✅ Admin ID: {ADMIN_ID or 'Not set'}")
        print(f"✅ OpenRouter: {'Enabled' if OPENROUTER_API_KEY else 'Disabled'}")
        print(f"📊 Active Trades: {len(self.trade_manager.get_active_trades())}")
        print("=" * 50)
        print("\n🚀 Starting bot...")
        
        self.application = Application.builder().token(BOT_TOKEN).build()
        
        self.application.add_handler(CommandHandler("start", self.start_command))
        self.application.add_handler(CommandHandler("help", self.help_command))
        self.application.add_handler(CommandHandler("admin", self.admin_command))
        self.application.add_handler(CommandHandler("setchat", self.setchat_command))
        self.application.add_handler(CommandHandler("signal", self.signal_command))
        self.application.add_handler(CommandHandler("analyze", self.analyze_command))
        self.application.add_handler(CommandHandler("status", self.status_command))
        self.application.add_handler(CallbackQueryHandler(self.callback_handler))
        
        async def post_init(application):
            interval_minutes = self.settings.get('update_interval_minutes', 15)
            if application.job_queue:
                application.job_queue.run_repeating(
                    self.live_update_job, 
                    interval=interval_minutes * 60, 
                    first=60
                )
                print(f"✅ Live updates scheduled every {interval_minutes} minutes")
            else:
                print("⚠️ Job queue not available - live updates disabled")
        
        self.application.post_init = post_init
        
        print("✅ Bot is running! Press Ctrl+C to stop.")
        self.application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == '__main__':
    bot = ForexSignalBot()
    bot.run()
