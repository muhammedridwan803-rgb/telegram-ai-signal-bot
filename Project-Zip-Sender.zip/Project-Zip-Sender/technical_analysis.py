"""
STEP 2: REAL TECHNICAL INDICATORS
Using real market data to generate actual signals
"""

import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

class TechnicalAnalyzer:
    def __init__(self):
        self.symbols = {
            'forex': {
                'EURUSD': 'EURUSD=X',
                'GBPUSD': 'GBPUSD=X',
                'USDJPY': 'JPY=X',
                'AUDUSD': 'AUDUSD=X'
            },
            'futures': {
                'GOLD': 'GC=F',
                'SILVER': 'SI=F',
                'OIL': 'CL=F',
                'NAS100': 'NQ=F'
            },
            'crypto': {
                'BTC': 'BTC-USD',
                'ETH': 'ETH-USD',
                'SOL': 'SOL-USD'
            }
        }
    
    def get_market_data(self, yf_symbol, interval='5m', period='1d'):
        """Get real market data with multiple timeframes"""
        try:
            ticker = yf.Ticker(yf_symbol)
            data = ticker.history(period=period, interval=interval)
            
            if data.empty or len(data) < 20:
                print(f"⚠️ Not enough data for {yf_symbol}")
                return None
            
            return data
        except Exception as e:
            print(f"❌ Error getting {yf_symbol}: {e}")
            return None
    
    def calculate_indicators(self, data):
        """Calculate real technical indicators"""
        if data is None or len(data) < 20:
            return None
        
        df = data.copy()
        
        # Current price
        current_price = df['Close'].iloc[-1]
        prev_price = df['Close'].iloc[-2] if len(df) > 1 else current_price
        
        # 1. Simple Moving Averages
        df['SMA_20'] = df['Close'].rolling(window=20).mean()
        df['SMA_50'] = df['Close'].rolling(window=50).mean()
        
        # 2. RSI (Relative Strength Index)
        delta = df['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['RSI'] = 100 - (100 / (1 + rs))
        
        # 3. MACD
        exp1 = df['Close'].ewm(span=12, adjust=False).mean()
        exp2 = df['Close'].ewm(span=26, adjust=False).mean()
        df['MACD'] = exp1 - exp2
        df['Signal_Line'] = df['MACD'].ewm(span=9, adjust=False).mean()
        
        # 4. Bollinger Bands
        df['BB_Middle'] = df['Close'].rolling(window=20).mean()
        bb_std = df['Close'].rolling(window=20).std()
        df['BB_Upper'] = df['BB_Middle'] + (bb_std * 2)
        df['BB_Lower'] = df['BB_Middle'] - (bb_std * 2)
        
        # Current values
        current_rsi = df['RSI'].iloc[-1] if not pd.isna(df['RSI'].iloc[-1]) else 50
        current_macd = df['MACD'].iloc[-1] if not pd.isna(df['MACD'].iloc[-1]) else 0
        macd_signal = df['Signal_Line'].iloc[-1] if not pd.isna(df['Signal_Line'].iloc[-1]) else 0
        
        # Determine signal
        signal_strength = 0
        signal_type = "NEUTRAL"
        
        # RSI signals
        if current_rsi < 30:
            signal_strength += 25  # Oversold, potential BUY
        elif current_rsi > 70:
            signal_strength -= 25  # Overbought, potential SELL
        
        # MACD signals
        if current_macd > macd_signal:
            signal_strength += 20  # Bullish crossover
        else:
            signal_strength -= 20  # Bearish crossover
        
        # Price vs SMA
        if current_price > df['SMA_20'].iloc[-1]:
            signal_strength += 15
        else:
            signal_strength -= 15
        
        # Bollinger Band position
        bb_position = (current_price - df['BB_Lower'].iloc[-1]) / (df['BB_Upper'].iloc[-1] - df['BB_Lower'].iloc[-1])
        if bb_position < 0.2:
            signal_strength += 10  # Near lower band
        elif bb_position > 0.8:
            signal_strength -= 10  # Near upper band
        
        # Determine final signal
        if signal_strength >= 20:
            signal_type = "BUY"
            confidence = min(50 + signal_strength, 90)
        elif signal_strength <= -20:
            signal_type = "SELL"
            confidence = min(50 + abs(signal_strength), 90)
        else:
            confidence = 50
        
        # Calculate risk levels
        bb_width = (df['BB_Upper'].iloc[-1] - df['BB_Lower'].iloc[-1]) / df['BB_Middle'].iloc[-1]
        volatility = bb_width * 100  # Percentage
        
        if volatility < 1:
            risk_level = "LOW"
        elif volatility < 3:
            risk_level = "MEDIUM"
        else:
            risk_level = "HIGH"
        
        return {
            'current_price': round(current_price, 4),
            'signal': signal_type,
            'confidence': round(confidence),
            'indicators': {
                'rsi': round(current_rsi, 1),
                'macd': round(current_macd, 4),
                'above_sma_20': current_price > df['SMA_20'].iloc[-1],
                'bb_position': round(bb_position, 2),
                'volatility': round(volatility, 2)
            },
            'risk_level': risk_level,
            'timestamp': datetime.now().isoformat()
        }
    
    def analyze_symbol(self, symbol_name, yf_symbol):
        """Complete analysis for one symbol"""
        print(f"\n�� Analyzing {symbol_name} ({yf_symbol})...")
        
        # Get 5-minute data for short-term analysis
        data = self.get_market_data(yf_symbol, interval='5m')
        
        if data is None:
            return None
        
        analysis = self.calculate_indicators(data)
        
        if analysis:
            print(f"   Price: ${analysis['current_price']}")
            print(f"   Signal: {analysis['signal']} ({analysis['confidence']}%)")
            print(f"   RSI: {analysis['indicators']['rsi']}")
            print(f"   Risk: {analysis['risk_level']}")
        
        return analysis

def test_technical_analysis():
    """Test real technical analysis"""
    print("🧪 REAL TECHNICAL ANALYSIS TEST")
    print("=" * 50)
    
    analyzer = TechnicalAnalyzer()
    
    # Test a few symbols
    test_pairs = [
        ('EUR/USD', 'EURUSD=X'),
        ('GOLD', 'GC=F'),
        ('BITCOIN', 'BTC-USD')
    ]
    
    signals = []
    
    for name, symbol in test_pairs:
        analysis = analyzer.analyze_symbol(name, symbol)
        if analysis and analysis['confidence'] >= 60:
            signals.append({
                'name': name,
                'symbol': symbol.split('=')[0].split('-')[0],
                'analysis': analysis
            })
    
    print("\n" + "=" * 50)
    print(f"✅ Found {len(signals)} potential signals")
    
    if signals:
        print("\n🎯 **POTENTIAL SIGNALS:**")
        for signal in signals:
            print(f"   • {signal['name']}: {signal['analysis']['signal']} "
                  f"({signal['analysis']['confidence']}% confidence)")
    
    return signals

if __name__ == '__main__':
    test_technical_analysis()
