import os
import json
from dotenv import load_dotenv

load_dotenv()

# Telegram Bot Token (from @BotFather)
BOT_TOKEN = os.getenv('BOT_TOKEN')

# Admin User ID (your Telegram user ID)
ADMIN_ID = os.getenv('ADMIN_ID')

# OpenRouter API (optional for now)
OPENROUTER_API_KEY = os.getenv('OPENROUTER_API_KEY', '')

# Settings file path
SETTINGS_FILE = 'bot_settings.json'

# Default settings structure
DEFAULT_SETTINGS = {
    "forex_channel_id": "",
    "forex_topic_id": "",
    "futures_channel_id": "", 
    "futures_topic_id": "",
    "risk_rr_min": 1.5,  # Minimum Risk:Reward ratio
    "confidence_threshold": 75,  # Minimum AI confidence %
    "max_signals_per_day": 5
}

def load_settings():
    """Load settings from file or create default"""
    try:
        with open(SETTINGS_FILE, 'r') as f:
            settings = json.load(f)
            # Ensure all keys exist
            for key in DEFAULT_SETTINGS:
                if key not in settings:
                    settings[key] = DEFAULT_SETTINGS[key]
            return settings
    except FileNotFoundError:
        # Create file with default settings
        save_settings(DEFAULT_SETTINGS)
        return DEFAULT_SETTINGS.copy()

def save_settings(settings):
    """Save settings to file"""
    with open(SETTINGS_FILE, 'w') as f:
        json.dump(settings, f, indent=2)

# Load settings
SETTINGS = load_settings()
